using System;

namespace Clac
{
    public class Add
    {
        public float add(float a,float b)
        {
            return a+b;
        }

    } 
}