Imports System

Namespace Calculator
    Public Class Mul
        Public Function mul(ByVal a As Single, ByVal b As Single) As Single
            Return a * b
        End Function
    End Class
End Namespace
