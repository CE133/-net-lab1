using System;

namespace Calculator
{
    public class Sub
    {

        public float sub(float a,float b)
        {
            return a-b;
        }

    } 
}