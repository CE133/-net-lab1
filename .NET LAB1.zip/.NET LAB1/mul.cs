using System;

namespace Calculator
{
    public class Mul
    {

        public float mul(float a,float b)
        {
            return a*b;
        }
    } 
}