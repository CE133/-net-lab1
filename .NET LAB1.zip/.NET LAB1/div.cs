using System;

namespace Calculator
{
    public class Div
    {

        public float div(float a,float b)
        {
            return a/b;
        }

    } 
}